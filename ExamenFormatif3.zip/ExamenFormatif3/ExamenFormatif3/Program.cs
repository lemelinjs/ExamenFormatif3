﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace ExamenFormatif3
{
    class Program
    {
        static int position = 0, tentatives = 0;
        static bool[] tableauJeu = new bool[100];
        static void Main(string[] args)
        {
            /* Programme qui enregistre les déplacement d'une personne en X 
             * 
             * Faire un tableau de valeur booleene - FAIT
             * 
             * La position 0 et 99 valent true - FAIT
             * Les autres sont générée aléatoirement - FAIT
             * 
             * A 3 cases vers la gauche - FAIT
             * S 2 cases vers la gauche - FAIT
             * G 2 cases vers la droite - FAIT
             * H 4 cases vers la droite- FAIT
            * 
            * Indiquer la positon du personnage après tous les déplacements - FAIT
            * 
            * Le CR est permis - FAIT
            * 
            * Le tableau de position devient impossible après 4 faux - FAIT
            * 
            *
            * 
            * Le jeu termine quand l'utilisateur clique q -FAIT
            * 
            * Comptabiliser  et afficher le nombre d'essai (l'utilisateur est tombé sur une case false) pour traverser - FAIT
            * 
            * Fonction AffichageEntier() qui affiche le tableau activé par Y - FAIT
            * Fonction Affichage10() qui affiche les 10 cellules après le personnage activé par P - FAIT
            *
             */

            // Déclaration des variables
            String choix = "";
            Random nbRand = new Random();
            int vraiOuFaux = 0;
            
            



        //Attriber les valeurs dans le tableau
        tableauJeu[0] = true;
            tableauJeu[99] = true;

            for (int i = 1; i < tableauJeu.Length-2; i++)
            {
                vraiOuFaux = nbRand.Next(0, 2);
                switch (vraiOuFaux)
                {
                    case 1 :
                        tableauJeu[i] = true;
                        break;
                    case 2:
                        tableauJeu[i] = true;
                        break;
                    default:
                        break;
                }
                
            }   
            // Conditions de sortie du jeu
            while (choix.ToLower() !=  "q" || tentatives >4 )
            {
                Console.Clear();
                Console.WriteLine("A - 3 case vers la Gauche, S-2 cases vers la gauche, G - 2 cases vers la droite, H - 4 cases vers la droite");
                Console.WriteLine("-----------------------------------------------------------------------------------------------------------");
                Console.WriteLine("INCICES (1 tentative) Y - Afficher Tableau / P - Afficher 10 prochaines cases");
                Console.WriteLine("Vous avez droit à 4 tentatives, vous êtes présentement à votre " + tentatives + " tentative et votre position = " + 
                    position);
                choix = Console.ReadLine();

                // Afficher la position du personnage

                // Vérifier les touches A S D G H
                if (choix.ToLower() =="a")
                {
                    if (position-3 <0 )
                    {
                        Console.WriteLine("Vous ne pouvez pas reculer si loin");
                        Console.WriteLine("Appyez sur ENTER");
                        tentatives += 1;

                    }
                    else
                    {
                        position -= 3;
                        if (tableauJeu[position] == true)
                        {
                            Console.WriteLine("Fiou, vous avez tombé sur la position " + position + " et elle est vraie - Presser ENTER");
                        }
                        else
                        {
                            Console.WriteLine("ouf, vous avez tombé sur la position " + position + " et elle est fausse - Presser ENTER");
                            tentatives += 1;
                        }

                    }
                    Console.ReadLine();
                }
                else if (choix.ToLower() == "s")
                {
                    if (position - 2 < 0)
                    {
                        Console.WriteLine("Vous ne pouvez pas reculer si loin");
                        Console.WriteLine("Appyez sur ENTER");
                        tentatives += 1;

                    }
                    else
                    {
                        position -= 2;
                        if (tableauJeu[position] == true)
                        {
                            Console.WriteLine("Fiou, vous avez tombé sur la position " + position + " et elle est vraie - Presser ENTER");
                        }
                        else
                        {
                            Console.WriteLine("ouf, vous avez tombé sur la position " + position + " et elle est fausse - Presser ENTER");
                            tentatives += 1;
                        }

                    }
                Console.ReadLine();
                
                    
                }
                else if (choix.ToLower() == "d")
                {
                    if (position + 1 > 99)
                    {
                        Console.WriteLine("VOUS AVEZ GAGNÉ!");
                        Console.WriteLine("Appyez sur ENTER");

                    }
                    else
                    {
                        position += 1;
                        if (tableauJeu[position] == true)
                        {
                            Console.WriteLine("Fiou, vous avez tombé sur la position " + position + " et elle est vraie - Presser ENTER");
                        }
                        else
                        {
                            Console.WriteLine("ouf, vous avez tombé sur la position " + position + " et elle est fausse - Presser ENTER");
                            tentatives += 1;
                        }

                    }
                    Console.ReadLine();
                }
                else if (choix.ToLower() == "g")
                {
                    if (position + 2 > 99)
                    {
                        Console.WriteLine("VOUS AVEZ GAGNÉ!");
                        Console.WriteLine("Appyez sur ENTER");

                    }
                    else
                    {
                        position += 2;
                        if (tableauJeu[position] == true)
                        {
                            Console.WriteLine("Fiou, vous avez tombé sur la position " + position + " et elle est vraie - Presser ENTER");
                        }
                        else
                        {
                            Console.WriteLine("ouf, vous avez tombé sur la position " + position + " et elle est fausse - Presser ENTER");
                            tentatives += 1;
                        }

                    }
                    Console.ReadLine();
                }
                else if (choix.ToLower() == "h")
                {
                    if (position + 4 > 99)
                    {
                        Console.WriteLine("VOUS AVEZ GAGNÉ!");
                        Console.WriteLine("Appyez sur ENTER");

                    }
                    else
                    {
                        position += 4;
                        if (tableauJeu[position] == true)
                        {
                            Console.WriteLine("Fiou, vous avez tombé sur la position " + position + " et elle est vraie - Presser ENTER");
                        }
                        else
                        {
                            Console.WriteLine("ouf, vous avez tombé sur la position " + position + " et elle est fausse - Presser ENTER");
                            tentatives += 1;
                        }

                    }
                    Console.ReadLine();
                }
                
                else if (choix.ToLower() == "y")
                {
                    AffichageEntier();
                }
                else if (choix.ToLower() == "p")
                {
                    Affichage10();
                }

                if (tentatives > 4)
                {
                    Console.WriteLine("Toutes les tentatives ont été épuisées - Nouvelle partie - Presser ENTER");
                    tentatives = 0;
                    position = 0;
                    Console.ReadLine();
                }
            }
           
        }

         static void AffichageEntier()
        {
            for (int i = 0; i < tableauJeu.Length; i++)
            {
                if (i==0)
                {
                    Console.Write("(");
                }
                if (i > 0 && i<99)
                {
                   Console.Write(tableauJeu[i]+", "); 
                }
                
                if (i==99)
                {
                    Console.WriteLine(tableauJeu[i] + ")");
                }
                
            }
            Console.WriteLine("Appuyez sur enter");
            tentatives++;
            Console.ReadLine();

        }
        static void Affichage10()
        {
            for (int i = position+1; i <= position+10; i++)
            {
                if (i>99)
                {
                    i = 99;
                }
                if (i == position +1)
                {
                    Console.Write("BONHOMME <<<<<< ");
                }
                if (i> position+1 && i<= position+10 && i<= 99 )
                {
                    Console.Write(tableauJeu[i] + ", ");
                }
                else if (i == position +10 || i == 99)
                {
                    Console.WriteLine(tableauJeu[i] + ")");
                }

            }
            Console.WriteLine("Appuyez sur enter");
            tentatives++;
            Console.ReadLine();

        }
    }
}
